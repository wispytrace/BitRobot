from django.apps import AppConfig


class BitappConfig(AppConfig):
    name = 'bitApp'
