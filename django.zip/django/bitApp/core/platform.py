from huobi.client.account import AccountClient
from huobi.client.market import MarketClient
from bitApp.models import *

class HuoBi:

    def __init__(self):
        # self.g_api_key = "3cca6511-04f562c0-94f7cb02-mjlpdje3ld"
        # self.g_secret_key = "595e8002-0853b96c-13d863c5-fb6a5"
        # self.g_account_id = 50267759

        # self.account_client = AccountClient(api_key=self.g_api_key, secret_key=self.g_secret_key)
        self.market_client = MarketClient()
        # self.trade_client = TradeClient(api_key=self.g_api_key, secret_key=self.g_secret_key)

        self.price_dict = {}



    def get_currency_price(self, symbol_name):

        if self.price_dict.get(symbol_name) is None:
            self.price_dict[symbol_name] = self.market_client.get_market_detail(symbol_name).close

        currency_price = self.price_dict[symbol_name]
        return currency_price

    def update_price(self):

        for currency in currency_arry:
            self.price_dict[currency] = self.market_client.get_market_detail(currency).close
        currency_price = self.price_dict[currency]
        return currency_price

    def add_api(self, api_key, secret_key):
        account_client = AccountClient(api_key=api_key, secret_key=secret_key)
        accounts = account_client.get_accounts()
        apis = Api.objects.all()
        api_id = len(apis)
        api = Api(api_id=api_id, api_key=api_key, secret_key=secret_key)

        account_count = len(Account.objects.all())
        for item in accounts:
            account = Account(account_id=account_count, api_id=api_id, system_id=item.id)
            account.save()
        api.save()

    def get_apis(self):

        apis = Api.objects.all()
        api_dict = {}
        api_count = len(apis)

        for i in range(api_count):
            api_dict[i] = apis[i].api_id

        return api_dict, api_count

    def get_currencys(self):

        currency_dict = {}
        currency_count = len(currency_arry)
        for i in range(currency_count):
            currency_dict[i] = currency_arry[i]

        return currency_dict, currency_count

    def get_accounts(self, api_id):
        accounts = Account.objects.filter(api_id=api_id)
        account_dict = {}
        account_count = len(accounts)

        for i in range(account_count):
            account_dict[i] = accounts[i].api_id

        return account_dict, account_count

    def clear_accounts(self):

        apis = Api.objects.all()
        accounts = Account.objects.all()
        for api in apis:
            api.delete()
        for account in accounts:
            account.delete()





