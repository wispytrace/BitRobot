import requests
import time

URL_IP = "http://222.195.78.31:8000/"


def send_req():

    try:

        update_res = requests.get(url=URL_IP+"api/update")
        print(update_res.text)
    except Exception as e:
        print(repr(e))



if __name__ == '__main__':

    while True:
        send_req()
        time.sleep(3)