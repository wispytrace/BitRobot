g_api_key = "3cca6511-04f562c0-94f7cb02-mjlpdje3ld"
g_secret_key = "595e8002-0853b96c-13d863c5-fb6a5"

g_account_id = 50267759

# g_sub_uid = 123456
#
# g_account_id = 123456

